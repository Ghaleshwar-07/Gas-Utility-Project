from django.apps import AppConfig


class GasServiceAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gas_service_app'
